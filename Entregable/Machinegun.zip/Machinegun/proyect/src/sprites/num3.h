// Data created with Img2CPC - (c) Retroworks - 2007-2017
#ifndef _IMG_NUM3_H_
#define _IMG_NUM3_H_

#include <types.h>
extern const u8 num3_pal[16];

#define NUM3_SP_W 8
#define NUM3_SP_H 16
extern const u8 num3_sp[2 * 8 * 16];

#endif
